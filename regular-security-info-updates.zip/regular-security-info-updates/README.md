# Daily-Security-Updates
This is a script which queries the https://euvd.enisa.europa.eu/ api for newly released vulnerabilities, filters it and sends it to you via email. The information sent is customizable.
